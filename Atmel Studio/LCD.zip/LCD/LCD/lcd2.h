/*
 * lcd2.h
 *
 * Created: 23-Nov-17 10:13:17 PM
 *  Author: Chirag
 */ 


#ifndef LCD2_H_
#define LCD2_H_

void lcd_print2(char, char , unsigned int , int, char*);
void lcd_print3(char, char , unsigned int , int);
void lcd_print4(char, char, float, char*, char*);

#endif /* LCD2_H_ */